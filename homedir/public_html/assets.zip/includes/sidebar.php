<aside class="main-sidebar">
    <section class="sidebar position-relative"> 
	  	<div class="multinav">
		  <div class="multinav-scroll" style="height: 97%;">	
			  <!-- sidebar menu-->
			  <ul class="sidebar-menu" data-widget="tree">	
			    <li class="header">Main Menu</li>
				<li><a href="index"><i data-feather="home"></i><span>Dashboard</span></a></li>
				<li><a href="raw-data"><i data-feather="grid"></i><span>Raw Packet Data</span></a></li>
				<li><a href="timeline"><i data-feather="grid"></i><span>Packet's Timeline</span></a></li>
			  </ul>
		  </div>
		</div>
    </section>
</aside>